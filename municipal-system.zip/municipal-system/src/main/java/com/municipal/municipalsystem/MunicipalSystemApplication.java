package com.municipal.municipalsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MunicipalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MunicipalSystemApplication.class, args);
	}

}
